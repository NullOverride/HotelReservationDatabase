To run the GUI program, add mysql-connector-java-5.1.40-bin.jar to the build path.
Compile HotelGUI.java.

The connection requires to be run on localhost on port 3306. There will be a prompt for the username and password.

All the sample data, triggers, stored procedure is included in hotelclean.sql.
